
int incrementar(char *nome[], unsigned valor);

int agregar(char *prefixo[], unsigned nivel, char *path);
